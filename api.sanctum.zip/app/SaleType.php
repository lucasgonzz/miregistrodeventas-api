<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleType extends Model
{
    protected $guarded = [];
}
