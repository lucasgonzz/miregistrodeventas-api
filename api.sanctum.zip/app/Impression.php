<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Impression extends Model
{
    protected $guarded = [];
}
