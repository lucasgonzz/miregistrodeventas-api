@component('mail::message')
# Introduction

{{ $buyer->name }}, {{ $commerce->company_name }} confirmó tu pedido.

@component('mail::button', ['url' => 'https://kioscoverde.com'])
Ver pedido
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
