<?php $__env->startComponent('mail::message'); ?>
# Nuevo Pedido

Hola <?php echo e($provider_order->provider->name); ?>, te acercamos nuestro pedido mediante el siguiente documento PDF

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
VER PDF
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Gracias
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\miregistrodeventas-api\resources\views/mail/providerOrder.blade.php ENDPATH**/ ?>