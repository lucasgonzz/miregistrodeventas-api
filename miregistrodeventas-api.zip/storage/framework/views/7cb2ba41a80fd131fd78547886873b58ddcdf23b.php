<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\miregistrodeventas-api\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>