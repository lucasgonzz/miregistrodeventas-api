<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperBudgetTitle extends Model
{
    //
}
