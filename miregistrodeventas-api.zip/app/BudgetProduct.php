<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BudgetProduct extends Model
{
    protected $guarded = [];
}
