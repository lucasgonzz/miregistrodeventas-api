<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IvaCondition extends Model
{
    protected $guarded = [];
}
