<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderProductionStatus extends Model
{
    protected $guarded = [];
}
