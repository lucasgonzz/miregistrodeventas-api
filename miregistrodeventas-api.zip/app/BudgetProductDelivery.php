<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BudgetProductDelivery extends Model
{
    protected $guarded = [];
}
