<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProviderOrderStatus extends Model
{
    protected $guarded = [];
}
