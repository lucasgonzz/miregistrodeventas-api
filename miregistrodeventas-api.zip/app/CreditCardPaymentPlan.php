<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CreditCardPaymentPlan extends Model
{
    protected $guarded = [];
}
