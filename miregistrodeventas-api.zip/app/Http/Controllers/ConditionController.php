<?php

namespace App\Http\Controllers;

use App\Condition;
use App\Http\Controllers\Helpers\StringHelper;
use Illuminate\Http\Request;

class ConditionController extends Controller
{
    function index() {
        $conditions = Condition::where('user_id', $this->userId())
                                ->get();
        return response()->json(['conditions' => $conditions], 200);
    }

    function store(Request $request) {
        $condition = Condition::create([
            'name'          => StringHelper::modelName($request->name),
            'description'   => StringHelper::modelName($request->description),
            'user_id'       => $this->userId(),
        ]);
        return response()->json(['condition' => $condition], 200); 
    }

    function update(Request $request) {
        $condition = Condition::find($request->id);
        $condition->name = StringHelper::modelName($request->name);
        $condition->description = StringHelper::modelName($request->description);
        $condition->save();
        return response()->json(['condition' => $condition], 200); 
    }
}
