<?php

namespace App\Http\Controllers;

use App\Article;
use App\Budget;
use App\Http\Controllers\Helpers\ArticleHelper;
use App\OrderProduction;
use App\User;
use Illuminate\Http\Request;

class HelperController extends Controller
{
    function setArticlesFromBudgets($company_name) {
        $user = User::where('company_name', $company_name)->first();
        $budgets = Budget::where('user_id', $user->id)->get();
        foreach ($budgets as $budget) {
            $budget->articles->detach();
            foreach ($budget->products as $product) {
                $article = Article::create([
                    'bar_code'  => $product->bar_code,
                    'name'      => $product->name,
                    'slug'      => ArticleHelper::slug($product->name),
                    'status'    => 'inactive',
                ]);
                $budget->articles()->attach($article->id, [
                                        'amount'    => $product->amount,
                                        'price'     => $product->price,
                                        'bonus'     => $product->bonus,
                                        'location'  => $product->location,
                                    ]);
            }
        }
    }

    function setArticlesFromOrderProductions($company_name) {
        $user = User::where('company_name', $company_name)->first();
        $order_productions = OrderProduction::where('user_id', $user->id)->get();
        foreach ($order_productions as $order_production) {
            if ($order_production->budget->delivery_and_placement == 1) {
                $order_production->observations = 'Con colocacion';
                $order_production->save();
            }
            foreach ($order_production->budget->articles as $article) {
                $order_production->articles()->attach($article->id, [
                                        'amount'    => $article->pivot->amount,
                                        'price'     => $article->pivot->price,
                                        'bonus'     => $article->pivot->bonus,
                                        'location'  => $article->pivot->location,
                                    ]);
            }
        }
    }
}
