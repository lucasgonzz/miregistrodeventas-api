<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentMethodType extends Model
{
    protected $guarded = [];
}
