<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperBudgetFeature extends Model
{
    protected $guarded = [];
}
